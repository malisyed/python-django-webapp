from django.shortcuts import render, redirect
from django.views.generic import CreateView
from django.contrib.auth.models import User
from .forms import UserRegistrationForm, UserUpdateForm, ProfileUpdateForm
from django.contrib.auth.decorators import login_required

class RegisterCreateView(CreateView):
	model = User
	template_name = "users/register.html"
	context_object_name = "form"
	form_class = UserRegistrationForm
	success_url = '/user/login'

@login_required
def profile_view(request):
	if request.method == "POST":
		user_update_form = UserUpdateForm(request.POST, instance = request.user)
		profile_update_form = ProfileUpdateForm(request.POST, request.FILES, instance = request.user.profile)
		if user_update_form.is_valid and profile_update_form.is_valid():
			user_update_form.save()
			profile_update_form.save()
			return redirect('/') 
	else:
		user_update_form = UserUpdateForm(instance = request.user)
		profile_update_form = ProfileUpdateForm(instance = request.user.profile)
	context = {
		'user_update_form' : user_update_form,
		'profile_update_form' : profile_update_form
	}
	return render(request, 'users/profile.html', context)